package com.myprojects.MyChatApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyChatAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
